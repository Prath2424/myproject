
export interface Chapter {
  title: string;
  content: string;
}

export interface Ebook {
  title: string;
  coverImageUrl: string;
  chapters: Chapter[];
}

export interface EbookContent {
    title: string;
    chapters: Chapter[];
}
