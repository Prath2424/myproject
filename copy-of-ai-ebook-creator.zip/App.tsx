import React, { useState, useCallback } from 'react';
import { Ebook } from './types';
import { generateEbookContent, generateCoverImage } from './services/geminiService';
import TopicForm from './components/TopicForm';
import EbookDisplay from './components/EbookDisplay';
import LoadingSpinner from './components/LoadingSpinner';
import { BookIcon } from './components/icons';

const App: React.FC = () => {
  const [ebook, setEbook] = useState<Ebook | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerateEbook = useCallback(async (topic: string, pageCount: number) => {
    setIsLoading(true);
    setError(null);
    setEbook(null);

    try {
      const [content, imageUrl] = await Promise.all([
        generateEbookContent(topic, pageCount),
        generateCoverImage(topic)
      ]);
      
      setEbook({
        title: content.title,
        chapters: content.chapters,
        coverImageUrl: imageUrl
      });
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      setError(`Failed to generate your ebook. Please try a different topic. Error: ${errorMessage}`);
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleTitleUpdate = (newTitle: string) => {
    if (ebook) {
      setEbook({ ...ebook, title: newTitle });
    }
  };

  return (
    <div className="min-h-screen text-white flex flex-col items-center p-4 sm:p-8 selection:bg-purple-500/30 relative z-10">
      <div className="w-full max-w-6xl mx-auto">
        <header className="text-center mb-12">
          <div className="inline-flex items-center gap-4 mb-4">
            <div className="p-3 bg-white/10 rounded-full border border-white/20">
              <BookIcon className="w-10 h-10 text-cyan-300" />
            </div>
            <h1 className="text-5xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-fuchsia-500 to-cyan-400">
              AI Ebook Creator
            </h1>
          </div>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Bring your ideas to life. Enter a topic and watch as AI crafts a unique ebook with a stunning cover, just for you.
          </p>
        </header>

        <main className="flex flex-col items-center gap-12">
          <section className="w-full max-w-2xl p-6 bg-white/10 border border-white/20 rounded-xl shadow-lg backdrop-blur-lg">
            <TopicForm onSubmit={handleGenerateEbook} isLoading={isLoading} />
          </section>

          <section className="w-full flex justify-center">
            {isLoading && <LoadingSpinner />}
            {error && (
              <div className="max-w-2xl p-4 text-center text-red-300 bg-red-900/50 border border-red-500 rounded-lg backdrop-blur-lg">
                <p className="font-semibold">Generation Failed</p>
                <p>{error}</p>
              </div>
            )}
            {ebook && <EbookDisplay ebook={ebook} onTitleUpdate={handleTitleUpdate} />}
             {!isLoading && !ebook && !error && (
              <div className="text-center text-gray-500 mt-8 border-2 border-dashed border-gray-700 rounded-xl p-12">
                <p>Your generated ebook will appear here.</p>
              </div>
            )}
          </section>
        </main>
        
        <footer className="text-center mt-16 text-gray-500 text-sm">
            <p>Powered by Google Gemini. Content is AI-generated and may require fact-checking.</p>
        </footer>
      </div>
    </div>
  );
};

export default App;