
import { GoogleGenAI, Type } from "@google/genai";
import { EbookContent } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const ebookContentSchema = {
    type: Type.OBJECT,
    properties: {
        title: {
            type: Type.STRING,
            description: "The main, compelling title of the ebook."
        },
        chapters: {
            type: Type.ARRAY,
            description: "An array of chapters for the ebook. The number of chapters should be appropriate for the requested length of the book.",
            items: {
                type: Type.OBJECT,
                properties: {
                    title: {
                        type: Type.STRING,
                        description: "The title of this specific chapter."
                    },
                    content: {
                        type: Type.STRING,
                        description: "The full content of this chapter, written in several paragraphs. The content should be detailed and comprehensive."
                    }
                },
                required: ["title", "content"]
            }
        }
    },
    required: ["title", "chapters"]
};

export const generateEbookContent = async (topic: string, pageCount: number): Promise<EbookContent> => {
    try {
        const prompt = `Generate a detailed, high-quality ebook about '${topic}'. The content should be substantial enough to fill approximately ${pageCount} pages when formatted for a standard A4 PDF with 12pt font. A rough guide is 300-400 words per page.
- Create a compelling main title for the ebook.
- Structure the content into a logical sequence of chapters. The number of chapters should be appropriate for the total length.
- Each chapter must have a clear, descriptive title.
- The content for each chapter should be comprehensive, well-written, and broken into multiple paragraphs.
- Ensure the total word count is significant to meet the page count requirement.
Provide the output in the specified JSON format.`;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: ebookContentSchema,
            },
        });
        
        const jsonText = response.text.trim();
        const parsedContent = JSON.parse(jsonText);

        // Basic validation
        if (!parsedContent.title || !Array.isArray(parsedContent.chapters)) {
            throw new Error("Invalid ebook structure received from API.");
        }

        return parsedContent;
    } catch (error) {
        console.error("Error generating ebook content:", error);
        throw new Error("Failed to generate ebook content. The model may have returned an unexpected format.");
    }
};

export const generateCoverImage = async (topic: string): Promise<string> => {
    try {
        const prompt = `An artistic, high-quality book cover for an ebook about '${topic}'. The style should be modern and abstract, with a sophisticated color palette. Avoid putting any text on the image. The design should be symbolic and evocative of the topic. Digital art.`;

        const response = await ai.models.generateImages({
            model: 'imagen-3.0-generate-002',
            prompt: prompt,
            config: {
                numberOfImages: 1,
                outputMimeType: 'image/jpeg',
                aspectRatio: '3:4',
            },
        });
        
        if (!response.generatedImages || response.generatedImages.length === 0) {
            throw new Error("No image was generated.");
        }

        const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
        return `data:image/jpeg;base64,${base64ImageBytes}`;

    } catch (error) {
        console.error("Error generating cover image:", error);
        throw new Error("Failed to generate a cover image.");
    }
};