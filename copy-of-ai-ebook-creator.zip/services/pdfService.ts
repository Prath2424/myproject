import { jsPDF } from 'jspdf';
import { Ebook } from '../types';

export const generateEbookPdf = async (ebook: Ebook): Promise<void> => {
    const doc = new jsPDF({
        orientation: 'p',
        unit: 'pt',
        format: 'a4',
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 60;
    const contentWidth = pageWidth - margin * 2;
    let pageNumber = 1;

    // --- Helper function to add page layout for content pages ---
    // A clean white background is used for all content pages to ensure maximum text readability.
    const addPageLayout = () => {
        doc.setFillColor(255, 255, 255);
        doc.rect(0, 0, pageWidth, pageHeight, 'F');
    };

    const addFooter = (num: number) => {
        doc.setFontSize(10);
        doc.setTextColor(140, 140, 140);
        doc.text(String(num), pageWidth / 2, pageHeight - margin / 2, { align: 'center' });
    };

    // --- Page 1: Cover Page ---
    if (ebook.coverImageUrl) {
        // @ts-ignore
        doc.addImage(ebook.coverImageUrl, 'JPEG', 0, 0, pageWidth, pageHeight, undefined, 'FAST');
    }
    
    // Add a dark gray overlay to make the white title text pop.
    // Using a solid color is more reliable than attempting transparency with the current jspdf setup.
    doc.setFillColor(50, 50, 50);
    doc.rect(0, pageHeight * 0.4, pageWidth, pageHeight * 0.25, 'F');
    
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(36);
    doc.setTextColor(255, 255, 255);
    const titleLines = doc.splitTextToSize(ebook.title, contentWidth * 1.2);
    doc.text(titleLines, pageWidth / 2, pageHeight / 2, { align: 'center', baseline: 'middle' });

    // --- Subsequent Pages: Chapters ---
    let yPos = margin;

    for (const chapter of ebook.chapters) {
        doc.addPage();
        pageNumber++;
        addPageLayout();
        addFooter(pageNumber);

        yPos = margin;

        // --- Chapter Title ---
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(24);
        // Use pure black for title for maximum contrast
        doc.setTextColor(0, 0, 0);
        const chapterTitleLines = doc.splitTextToSize(chapter.title, contentWidth);
        doc.text(chapterTitleLines, pageWidth / 2, yPos, { align: 'center' });
        yPos += chapterTitleLines.length * 24 + 30;

        // --- Chapter Content ---
        doc.setFont('times', 'normal');
        doc.setFontSize(12);
        // Use pure black for content text for maximum contrast
        doc.setTextColor(0, 0, 0);
        const lineHeight = 12 * 1.5;

        // Process content paragraph by paragraph for better layout
        const paragraphs = chapter.content.split('\n').filter(p => p.trim() !== '');

        for (const paragraph of paragraphs) {
            if (yPos + lineHeight > pageHeight - margin) {
                doc.addPage();
                pageNumber++;
                addPageLayout();
                addFooter(pageNumber);
                yPos = margin;
            }
            
            const lines = doc.splitTextToSize(paragraph, contentWidth);
            for (const line of lines) {
                if (yPos + lineHeight > pageHeight - margin) {
                    doc.addPage();
                    pageNumber++;
                    addPageLayout();
                    addFooter(pageNumber);
                    yPos = margin;
                }
                doc.text(line, margin, yPos);
                yPos += lineHeight;
            }
            yPos += lineHeight * 0.5; // Add a small gap between paragraphs
        }
    }

    // --- Save the PDF ---
    const safeTitle = ebook.title.replace(/[^a-z0-9]/gi, '_').toLowerCase();
    doc.save(`${safeTitle || 'ebook'}.pdf`);
};
