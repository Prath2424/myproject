import React, { useState } from 'react';
import { SparklesIcon } from './icons';

interface TopicFormProps {
  onSubmit: (topic: string, pageCount: number) => void;
  isLoading: boolean;
}

const TopicForm: React.FC<TopicFormProps> = ({ onSubmit, isLoading }) => {
  const [topic, setTopic] = useState('');
  const [pageCount, setPageCount] = useState(10);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (topic.trim() && !isLoading) {
      onSubmit(topic.trim(), pageCount);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-2xl">
      <div className="relative flex flex-col sm:flex-row gap-4">
        <input
          type="text"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          placeholder="e.g., 'The Future of Renewable Energy'"
          className="flex-grow w-full px-4 py-3 text-lg text-white bg-transparent border-b-2 border-gray-500 focus:border-purple-400 focus:outline-none transition-colors duration-300"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={isLoading || !topic.trim()}
          className="inline-flex items-center justify-center gap-2 px-6 py-3 font-semibold text-white bg-gradient-to-r from-purple-600 to-blue-500 rounded-lg shadow-lg hover:shadow-xl hover:scale-105 transform-gpu focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 focus:ring-offset-gray-900 transition-all duration-300 disabled:from-gray-600 disabled:to-gray-600 disabled:shadow-none disabled:scale-100 disabled:cursor-not-allowed"
        >
          <SparklesIcon className="w-5 h-5" />
          <span>Generate</span>
        </button>
      </div>
      <div className="mt-8">
        <label htmlFor="page-count" className="block mb-2 text-sm font-medium text-gray-300">
            Page Count: <span className="font-bold text-white text-base">{pageCount}</span>
        </label>
        <input
            id="page-count"
            type="range"
            min="5"
            max="100"
            value={pageCount}
            onChange={(e) => setPageCount(Number(e.target.value))}
            className="w-full h-2 bg-white/10 rounded-lg appearance-none cursor-pointer range-thumb-vibrant"
            disabled={isLoading}
        />
        <div className="flex justify-between text-xs text-gray-400 mt-1">
            <span>5</span>
            <span>100</span>
        </div>
      </div>
    </form>
  );
};

export default TopicForm;