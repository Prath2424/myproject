import React, { useState, useRef, useEffect } from 'react';
import { Ebook } from '../types';
import { DownloadIcon } from './icons';
import { generateEbookPdf } from '../services/pdfService';

interface EbookDisplayProps {
  ebook: Ebook | null;
  onTitleUpdate: (newTitle: string) => void;
}

const EbookDisplay: React.FC<EbookDisplayProps> = ({ ebook, onTitleUpdate }) => {
  const [isDownloading, setIsDownloading] = useState(false);
  // Use a ref to manage the contentEditable div to avoid conflicts with React's rendering
  const titleRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    // This effect syncs the editable h2 with the title from the parent state.
    // It's important for keeping the UI consistent if the title were to change
    // from an external source, and avoids conflicts during user input.
    if (titleRef.current && ebook && titleRef.current.innerText !== ebook.title) {
      titleRef.current.innerText = ebook.title;
    }
  }, [ebook?.title]);


  if (!ebook) {
    return null;
  }

  const handleDownload = async () => {
    if (!ebook) return;
    setIsDownloading(true);
    
    const currentTitle = titleRef.current?.innerText.trim() || ebook.title;
    
    // Create a temporary ebook object with the latest title for PDF generation
    const ebookForPdf = {
        ...ebook,
        title: currentTitle,
    };
    
    // Also update the app state if it has changed
    if (currentTitle !== ebook.title) {
        onTitleUpdate(currentTitle);
    }

    try {
      await generateEbookPdf(ebookForPdf);
    } catch (error) {
      console.error("Failed to generate PDF", error);
      alert("There was an error creating the PDF. Please try again.");
    } finally {
      setIsDownloading(false);
    }
  };
  
  const handleTitleBlur = () => {
    if (titleRef.current) {
        const newTitle = titleRef.current.innerText.trim();
        // Update parent state only if there's a meaningful change
        if (newTitle && newTitle !== ebook.title) {
            onTitleUpdate(newTitle);
        } else if (!newTitle) {
            // If the user deletes the title, restore it from the last good state
            titleRef.current.innerText = ebook.title;
        }
    }
  };

  const handleTitlePaste = (e: React.ClipboardEvent<HTMLDivElement>) => {
    e.preventDefault();
    const text = e.clipboardData.getData('text/plain');
    document.execCommand('insertText', false, text);
  };
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    // Prevent creating new lines on enter; instead, save the changes.
    if (e.key === 'Enter') {
      e.preventDefault();
      e.currentTarget.blur();
    }
  };

  return (
    <article className="w-full max-w-4xl bg-white/5 border border-white/10 rounded-2xl shadow-2xl shadow-black/20 p-6 sm:p-10 text-white animate-fade-in backdrop-blur-xl">
      <header className="mb-10 text-center">
        {/* Main page title for semantics, hidden visually */}
        <h1 className="text-4xl sm:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500 mb-4 break-words sr-only">
          {ebook.title}
        </h1>
        
        <div className="flex justify-center mb-8">
            <button
                onClick={handleDownload}
                disabled={isDownloading}
                className="inline-flex items-center justify-center gap-2 px-6 py-3 font-semibold text-white bg-gradient-to-r from-green-500 to-teal-500 rounded-lg shadow-lg hover:shadow-xl hover:scale-105 transform-gpu focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 focus:ring-offset-gray-900 transition-all duration-300 disabled:from-gray-600 disabled:to-gray-600 disabled:shadow-none disabled:scale-100 disabled:cursor-not-allowed"
            >
                <DownloadIcon className="w-5 h-5" />
                <span>{isDownloading ? 'Generating...' : 'Download Ebook'}</span>
            </button>
        </div>

        {/* Interactive Cover Preview */}
        <div 
          className="w-full max-w-sm mx-auto overflow-hidden rounded-lg shadow-lg shadow-black/30 relative group cursor-pointer border border-white/10"
          onClick={() => titleRef.current?.focus()}
        >
          <img
            src={ebook.coverImageUrl}
            alt={`Cover for ${ebook.title}`}
            className="w-full h-auto object-cover aspect-[3/4] select-none pointer-events-none"
          />
          {/* Overlay for text */}
          <div className="absolute inset-0 flex items-center justify-center p-4 bg-black/30 group-hover:bg-black/50 transition-colors duration-300">
             <div 
                className="absolute w-full bg-black/60 backdrop-blur-sm"
                style={{ height: '25%', top: '40%' }}
              ></div>
             <h2
                ref={titleRef}
                contentEditable={true}
                onBlur={handleTitleBlur}
                onPaste={handleTitlePaste}
                onKeyDown={handleKeyDown}
                suppressContentEditableWarning={true}
                className="relative z-10 w-full font-bold text-white text-3xl text-center break-words cursor-text p-4 focus:outline-none"
                aria-label="Editable cover title"
              >
                {ebook.title}
              </h2>
          </div>
           <div className="absolute top-2 left-2 text-xs text-white bg-black/60 px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
             Click title to edit
           </div>
        </div>
        <p className="text-gray-400 mt-4 text-sm">Click the title on the cover to edit it.</p>

      </header>
      
      <main className="space-y-12 mt-10">
        {ebook.chapters.map((chapter, index) => (
          <section key={index} className="prose prose-invert prose-lg max-w-none prose-p:leading-relaxed prose-p:text-gray-300 bg-white/5 p-6 rounded-xl border border-white/10">
            <h2 className="text-3xl font-bold mb-4 !text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-300 pb-2">
                {chapter.title}
            </h2>
            <div className="whitespace-pre-wrap">{chapter.content}</div>
          </section>
        ))}
      </main>
    </article>
  );
};

export default EbookDisplay;